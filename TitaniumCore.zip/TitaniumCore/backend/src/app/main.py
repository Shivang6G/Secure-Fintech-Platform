import asyncio
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from app.api.endpoints import router as api_router
from app.core.database import AsyncSessionLocal
from app.models.domain import Organization
from app.services.recurring import RecurringEngine

logger = logging.getLogger("titanium_core.scheduler")

app = FastAPI(title="Secure FinTech Engine", version="0.1.0")

# Enable Cross-Origin Resource Sharing (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api/v1")

@app.get("/healthz")
async def health():
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Autonomous background worker: sweeps every organization once per interval
# and posts any recurring schedules that are due. This is intentionally a
# lightweight asyncio loop (no extra dependency such as APScheduler) so the
# container stays small; swap for a proper job queue before real production
# use with many tenants.
# ---------------------------------------------------------------------------
RECURRING_SWEEP_INTERVAL_SECONDS = 6 * 60 * 60  # every 6 hours

async def _recurring_sweep_loop():
    while True:
        try:
            async with AsyncSessionLocal() as session:
                org_ids = (await session.execute(select(Organization.id))).scalars().all()
                for org_id in org_ids:
                    results = await RecurringEngine.execute_due_for_org(session, org_id)
                    if results:
                        logger.info("Recurring sweep org=%s posted=%d", org_id, len(results))
                await session.commit()
        except Exception:
            logger.exception("Recurring sweep failed")
        await asyncio.sleep(RECURRING_SWEEP_INTERVAL_SECONDS)

@app.on_event("startup")
async def start_background_workers():
    asyncio.create_task(_recurring_sweep_loop())